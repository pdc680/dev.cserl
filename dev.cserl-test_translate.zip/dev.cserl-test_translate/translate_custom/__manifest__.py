{
    'name': 'Make fields translatable demo',
    'version': '1',
    'description': """
    """,
    'author': 'Odoo Limited',
    'depends': [
        'account'
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}